import React from "react";

const MultiSurfaceRoom = () => {
  return <div>MultiSurfaceRoom</div>;
};

export default MultiSurfaceRoom;
